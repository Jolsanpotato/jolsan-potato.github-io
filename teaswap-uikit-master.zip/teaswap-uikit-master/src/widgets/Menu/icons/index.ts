export {default as AuditIcon} from "./Audit"
export {default as DiscordIcon} from "./Discord"
export {default as DocsIcon} from "./Docs"
export { default as FarmIcon } from "./Farm";
export { default as GithubIcon } from "./Github";
export { default as GroupsIcon } from "./Groups";
export { default as HamburgerIcon } from "./Hamburger";
export { default as HamburgerCloseIcon } from "./HamburgerClose";
export { default as HomeIcon } from "./Home";
export { default as IfoIcon } from "./Ifo";
export { default as InfoIcon } from "./Info";
export { default as LanguageIcon } from "./Language";
export { default as LogoIcon } from "./Logo";
export { default as MediumIcon } from "./Medium";
export { default as MegaphoneIcon } from "./Megaphone";
export { default as MoonIcon } from "./Moon";
export { default as MoreIcon } from "./More";
export { default as NftIcon } from "./Nft";
export { default as PoolIcon } from "./Pool";
export { default as ReferralIcon } from "./Referral";
export { default as SunIcon } from "./Sun";
export { default as SpitIcon } from "./Spit";
export { default as TelegramIcon } from "./Telegram";
export { default as TicketIcon } from "./Ticket";
export { default as TradeIcon } from "./Trade";
export { default as MintIcon } from "./Mint";
export { default as BallonIcon } from "./Ballon";
export { default as SugarIcon } from "./Sugar";
export { default as TeaSportV1Icon } from "./TeaSportV1";
export { default as TwitterIcon } from "./Twitter";
export { default as RoadmapIcon } from "./Roadmap";
export { default as ListingsIcon } from "./Listings";
export { default as LiquidityIcon } from "./Liquidity";
export { default as GraphIcon } from "./Graph";

